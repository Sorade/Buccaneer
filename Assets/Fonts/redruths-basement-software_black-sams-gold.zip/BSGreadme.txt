Redruth's Basement Software

Black Sam's Gold
� 2001, 2006, 2011 RBS
Freeware

This font is distributed as-is, and has no warranties on it whatsoever, except that I am fairly sury it's virus-free and know that it works.

It is based on handwritten characters from a map reprinted in the NATIONAL GEOGRAPHIC (vol. 195 no. 5; May 1999) and the map reproduction is, itself, � National Geographic Society, with which Redruth's Basement is not affiliated in any way.  Most of the basic punctuation is there.  I will not tell you which letters I took straight off the map and which I improvized�they all look legitimate enough to flow together nicely.  

Distribute this disclaimer with the font at all times.  If you include it in a disc/CD collection, leave this .ZIP file separate and intact.  All modified versions need an editor's signature in the credits of the font file itself.  Thank you.

Enjoy!

<><
T.R.